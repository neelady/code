
<?php
 
 include("class.php");

 
 
$hostname = "localhost";
$db = "code";
$Username = "root";
$Password = "";
$conn = mysqli_connect($hostname,$Username,$Password,$db) Or DIE ("unable to connect database");
 
$manager = new manager();
if (isset($_POST['submit']))
{

     $manager->name =$_POST['name'];
     $manager->departmentName = $_POST['Dname'];
     $manager->postions = $_POST['position1'];

 
      

     
   
    $sql = "INSERT INTO `manager`( `name`, `department`, `positions`) VALUES ('$manager->name','$manager->departmentName','$manager->postions');";

     if ($conn->query($sql) === TRUE) {
		echo "New record created successfully";
		header("Location: generate/index.php");
	    } else {
		echo "Error: " . $sql . "<br>" . $conn->error;
	    }
	
	  $conn->close();
     
     /*
		$stmt = mysqli_stmt_init($conn);
		if(!mysqli_stmt_prepare($stmt,$sql))
		{
				
		  echo ' <script  type = "text/javascript">  alert("SQL ERROR") </script>';
		  exit();
			 
		} 
		else{
  
		 
		   mysqli_stmt_bind_param( $stmt,"sss",$manager->name, $manager->departmentName,$manager->positions);
		   mysqli_stmt_execute($stmt);
		   
		   if(mysqli_query($conn,$sql))
		   {
			 
			  echo ' <script  type = "text/javascript">  alert(" record saved Successfully") </script>';
			  exit();
	
		   }
           
        } */






    
  }


  




















?>






















<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>form-v1 by Colorlib</title>
	<!-- Mobile Specific Metas -->
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<!-- Font-->
	
</head>
<body>



   <form action="manager.php" method ="POST">
   
   
                         <fieldset>
						<legend> Full Name</legend>
						<input type="text" class="form-control" id="brand" name="name" placeholder="Full Name" required>
						</fieldset>
						<fieldset>
						<legend> Department Name</legend>
						<input type="text" class="form-control" id="brand" name="Dname" placeholder="Department Name" required>
						</fieldset>
                       
   
              <fieldset>
              
               <legend>choose positions</legend>
              
                <input type="checkbox" id="vehicle1" name="position1" value="Data Analyst">
                <label for="vehicle1"> Data Analyst</label><br>
              
              
              
        
              
                 </fieldset>

                 <button name = "submit">submit</button>
   
   
   </form>








</body>
</html>