
<?php
 include("class.php");

 
   $msg ="";
   $tell ="";
  $hostname = "localhost";
  $db = "code";
  $Username = "root";
  $Password = "";
  $conn = mysqli_connect($hostname,$Username,$Password,$db) Or DIE ("unable to connect database");

  $learner = new learner();
   if(isset($_POST['submit']))
   {
       $learner->id = $_POST['id'];
	   $learner->name = $_POST['first'];
	   $learner->surname = $_POST['last'];
	   $learner->gender = $_POST['gender'];
	   $learner->phone = $_POST['phone'];
	   if(isset($_POST['address'])){
		$learner->address1 = $_POST['address'];  
	   }
	   $learner->hobbies = $_POST['hobbies'];
	   $learner->brand = $_POST['brand'];
	   $learner->skills = $_POST['skills'];
	   $learner->high = $_POST['Qname'];
	   $learner->inst = $_POST['Iname'];
	   $learner->year = $_POST['date'];
	   $learner->pName = $_POST['Pname'];
	   $learner->pDesc = $_POST['desc'];
	    // path to store the uploaded image
	   $target = "pictures/".basename($_FILES['image']['name']);

	   $name = $_FILES['cv']['name'];
	   
      // $path =  "resume/".basename($_FILES['cv']['name']);
	   $learner->image =  addslashes(file_get_contents($_FILES['image']['tmp_name']));
	   $learner->cv = file_get_contents($_FILES['cv']['tmp_name']);
	   $path ="resume/".$name;
  
	   if( move_uploaded_file($learner->cv,$path))
	     {
			echo ' <script  type = "text/javascript">  alert("cv uploaded") </script>';
             
		 }
  
	  /* if($_REQUEST[‘Submit’] == ‘Submit’){
		$name = $_FILES[‘resume’][‘name’];
		$tmp_name = $_FILES[‘resume’][‘tmp_name’];
		$path = “resumes/”.$name;
		if(move_uploaded_file($tmp_name, $path)) {
		echo “Resume Uploaded”;
		}
		else{
		echo “Oops something went wrong !”;
		}
		}*/
		
	$sql = "INSERT INTO `profile`( `name`, `surname`, `id_num`, `gender`, `phone`, `address1`,  `Qname`, `Iname`, `date`, `Pname`, `desc_name`, `skills`, `brand`, `hobbies`, `cv`, `images`)  VALUES ('$learner->name','$learner->surname',' $learner->id',' $learner->gender',' $learner->phone',' $learner->address1','$learner->high','$learner->inst','$learner->year',' $learner->pName','$learner->pDesc','$learner->skills','$learner->brand','$learner->hobbies',$learner->cv','$learner->image');";
        
	if ($conn->query($sql) === TRUE) {
		echo "New record created successfully";
	} else {
		echo "Error: " . $sql . "<br>" . $conn->error;
	}
	
	$conn->close();
	 
		//$sql = "INSERT INTO `profile`( name, surname, id_num, gender, phone, address1, address2, zip, Qname, Iname,date,Pname,desc_name,skills,brand,hobbies,cv,images) VALUES (?,?,?,?,?,?,?,?,?,?,'$learner->year_obtained',?,?,?,?,?,'$learner->cv','$learner->image');";
		/*$sql = "INSERT INTO `profile`( `name`, `surname`, `id_num`, `gender`, `phone`, `address1`,  `Qname`, `Iname`, `date`, `Pname`, `desc_name`, `skills`, `brand`, `hobbies`, `cv`, `images`)  VALUES (?,?,?,?,?,?,?,?,?,?,'$learner->year',?,?,?,?,?,'$learner->cv','$learner->image');";
		$stmt = mysqli_stmt_init($conn);
		if(!mysqli_stmt_prepare($stmt,$sql))
		{
				
		  echo ' <script  type = "text/javascript">  alert("SQL ERROR") </script>';
		 exit();
			 
		} else{
  
		 
		   mysqli_stmt_bind_param( $stmt,"sssssssssssssss",$learner->name, $learner->surname, $learner->id,  $learner->gender, $learner->phone, $learner->address1,$learner->high,$learner->inst,$learner->pName,$learner->pDesc,$learner->skills,$learner->brand,$learner->hobbies);
		   mysqli_stmt_execute($stmt);
		   
		   if(mysqli_query($conn,$sql))
		   {
			 
			  echo ' <script  type = "text/javascript">  alert(" record saved Successfully") </script>';
			  exit();
	
		   }

	   }*/
	}













  





















?>



















<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>form-v1 by Colorlib</title>
	<!-- Mobile Specific Metas -->
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<!-- Font-->
	
</head>
<body>
	
		        <form class="form-register" action="createProfile.php" method="POST"  enctype="multipart/form-data">
		        	  <h2>
			            	
			            </h2>
			            <section>
			                
									<h3 class="heading">Peronal Infomation</h3>
									<p>Please enter your infomation and proceed to the next step so we can build your accounts.  </p>
							
										<fieldset>
											<legend>First Name</legend>
											<input type="text" class="form-control" id="first-name" name="first" placeholder="First Name" required>
										</fieldset>
								
										<fieldset>
											<legend>Last Name</legend>
											<input type="text" class="form-control" id="last-name" name="last" placeholder="Last Name" required>
										</fieldset>
								
										<fieldset>
											<legend>ID Number</legend>
											<input type="text" class="form-control" id="last-name" name="id" placeholder="ID Number" maxlength="13" required>
										</fieldset>
								

								
										<fieldset>
											<legend>Gender</legend>
											<input type="radio"  class="form-control" id="male"   name="gender" value="male">
                                            <label for="male">Male</label><br>
                                            <input type="radio"  class="form-control" id="female" name="gender" value="female">
                                            <label for="female">Female</label><br>
                                            <input type="radio"  class="form-control" id="other"  name="gender" value="other">
                                             <label for="other">Other</label>
										</fieldset>
								
								
										<fieldset>
											<legend>Your Email</legend>
											<input type="text" name="email" id="your_email" class="form-control" pattern="[^@]+@[^@]+.[a-zA-Z]{2,6}" placeholder="example@email.com" required>
										</fieldset>
								
								
										<fieldset>
											<legend>Phone Number</legend>
											<input type="text" class="form-control" id="phone" name="phone" placeholder="+1 888-999-7777" required>
										</fieldset>
								
							
										<fieldset>
											<legend>Address</legend>
											
                                            <label for="inputAddress">Address</label><br>
											<textarea class="form-control" id="exampleFormControlTextarea1" name ="address" rows="5"></textarea><br>
                                          
                                          
                                            
										</fieldset>
									




							
			            </section>
						<!-- SECTION 2 -->
			            <h2>
			            	
			            	<span class="step-text">Education</span>
			            </h2>
			            <section>
			                
									<h3 class="heading">Education</h3>
									<p>Please enter your infomation and proceed to the next step so we can build your profile.</p>
							
										<fieldset>
											<legend>Qualification Name</legend>
											<input type="text" class="form-control" id="Qname" name="Qname" placeholder="Qualification Name" required>
										</fieldset>
									
										<fieldset>
											<legend> Institution Name</legend>
											<input type="text" class="form-control" id="Iname" name="Iname" placeholder="Institution Name" required>
										</fieldset>

										<fieldset>
											<legend> Year Obtained</legend>
											<input type="date" class="form-control" id="date" name="date" min="2005-01-02" max="2020-10-29" placeholder="Year Obtained" required>
										</fieldset>

										<fieldset>
											<legend>Final Year Project</legend>
											<label for="project"> Project Name</label><br>
											<input type="text" class="form-control" id="date" name="Pname"  placeholder="Project Name" required><br>
											<label for="project"> Project Description</label><br>
											<textarea class="form-control" id="exampleFormControlTextarea1" name ="desc" rows="5"></textarea><br>
										</fieldset>

										<fieldset>
											<legend>Technical Skills</legend>
											<textarea class="form-control" id="exampleFormControlTextarea1" name ="skills" rows="5"></textarea><br>
										</fieldset>
									
				              
			            </section>
			            <!-- SECTION 3 -->
			            <h2>
			            	
			            	<span class="step-text">Interests</span>
			            </h2>
			            <section>
					  


						<fieldset>
						<legend> Personal Brand</legend>
						<input type="text" class="form-control" id="brand" name="brand" placeholder="Personal Brand" required>
						</fieldset>
						<fieldset>
						<legend> Hobbies</legend>
						<textarea class="form-control" id="exampleFormControlTextarea1" name ="hobbies" rows="3"></textarea>
						</fieldset>
                  
               




			              
						</section>
						


						</section>
			            <!-- SECTION 3 -->
			            <h2>
			            	
			            	<span class="step-text">Attachments</span>
			            </h2>
			            <section>
					  


						<fieldset>
						<legend> Upload CV</legend>
						<input type="file" class="form-control"  name="cv"  required>
						</fieldset>
						<fieldset>
						<legend> Image</legend>
						<input type="file" class="form-control"  name="image"  required>
						</fieldset>
                  
						</section>
						

                       <button name="submit">submit</button>
		        	
		        </form>
		
	
    </body>
    </html>