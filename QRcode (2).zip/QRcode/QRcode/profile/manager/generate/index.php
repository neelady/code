<?php

// var_dump(extension_loaded("iconv"));
 // die();
 header("Content-Type: image/png");
 include('libs/phpqrcode/qrlib.php'); 

 require"vendor/autoload.php";
 //use Endriod\QrCode\QrCode;
 /*use Endroid\QrCode\ErrorCorrectionLevel;
 use Endroid\QrCode\LabelAlignment;
 use Endroid\QrCode\Response\QrCodeResponse;*/
 //$qrcode = new QrCode("I am here");
 $qrCode->setSize(300);
 $qrCode->setMargin(10); 
 //echo $qrcode->writeString();
// die();
 

/* $qrCode->setRoundBlockSize(true, QrCode::ROUND_BLOCK_SIZE_MODE_MARGIN); // The size of the qr code is shrinked, if necessary, but the size of the final image remains unchanged due to additional margin being added (default)
 $qrCode->setRoundBlockSize(true, QrCode::ROUND_BLOCK_SIZE_MODE_ENLARGE); // The size of the qr code and the final image is enlarged, if necessary
 $qrCode->setRoundBlockSize(true, QrCode::ROUND_BLOCK_SIZE_MODE_SHRINK);*/
 //include('libs/phpqrcode/qrlib.php');
 $hostname = "localhost";
 $db = "code";
 $Username = "root";
 $Password = "";
 $conn = mysqli_connect($hostname,$Username,$Password,$db) Or DIE ("unable to connect database");

 /////////********************************************************** */
 /*$f = "visit.php";
 if(!file_exists($f)){
	touch($f);
	$handle =  fopen($f, "w" ) ;
	fwrite($handle,0) ;
	fclose ($handle);
 }*/
 $query = "SELECT * FROM manager;";
 $result = mysqli_query($conn,$query);

 while($rows = mysqli_fetch_array($result))
 {

    $name = $rows['name']; 
    $department = $rows['department']; 
    $position = $rows['positions']; 

   $tempDir = 'temp/'; 
	
    $filename = $name;
    //$qrCode->writeFile($tempDir.'/qrcode.png');

    $codeContents = 'mailto:'.$name.'?subject='.urlencode($department).'&body='.urlencode($position); 
   // $qrcode = new QrCode($codeContents, $tempDir.''.$filename.'.png', QR_ECLEVEL_L, 5);
	QRcode::png($codeContents, $tempDir.''.$filename.'.png', QR_ECLEVEL_L, 5);

 }




?>

<!DOCTYPE html>
<html lang="en-US">
	<head>
	<title>Quick Response (QR) Code Generator</title>
	<link rel="icon" href="img/favicon.ico" type="image/png">
	<link rel="stylesheet" href="libs/css/bootstrap.min.css">
	<link rel="stylesheet" href="libs/style.css">
	<script src="libs/navbarclock.js"></script>
     <style>
	 
	 *{
       
	    background-color: white;




	 }
	 
	 
	 
	 
	 
	 
	 </style>

	   
	</head>
    <body>
	<?php
			if(!isset($filename)){
				$filename = "author";
			}
			?>
     
    <div class="qr-field">
				<h2 style="text-align:center">QR Code Result: </h2>
				<center>
					<div class="qrframe" style="border:2px solid black; width:210px; height:210px;">
							<?php echo '<img src="temp/'. @$filename.'.png" style="width:200px; height:200px;"><br>'; ?>
					</div>
					<a class="btn btn-primary submitBtn" style="width:210px; margin:5px 0;" href="download.php?file=<?php echo $filename; ?>.png ">Download QR Code</a>
				</center>
			</div>
			
		</div>
	</body>
	




    </body>
    </html>