<?php
 
   require_once 'libs/phpqrcode/qrlib.php';
   $path ="temp/";
   $file =$path.uniqid()."png";
  
   // the output
      $text = "";
   QRcode::png($text,$file ,'L',10,2);


   echo "<center> <img src'".$file."'><center>";
  


?>

