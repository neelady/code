<?php

 
class database{


 

  protected $hostname = "localhost";
  protected $db = "code";
  protected $Username = "root";
  protected $Password = "";
   
    protected function conn(){

        $conn = mysqli_connect($hostname,$Username,$Password,$db) Or DIE ("unable to connect database");


        return $conn;

    }
  

}




class learner extends database {


 public $id;
 public $name;
 public $surname;
 public $gender;
 Public $phone;
 public $email;
 public $address1;
 public $hobbies;
 public $skills;
 public $brand;
 public $high;
 public $inst;
 public $year;
 public $pName;
 public $pDesc;
 public $image;
 public $cv;


  public  function checkfield()
 {
   if( empty ($this->id)|| empty($this->name) || empty($this->surname)|| empty($this->gender)|| empty($this->phone)|| empty($this->address1)|| empty($this->hobbies)|| empty($this->skills)|| empty($this->brand)|| empty($this->high)|| empty($this->inst)|| empty($this->year)|| empty($this->pName)|| empty($this->pDesc))
   {

      return true;

   }
  
    return false;


 }

   public function checkNames()
   {


    if (!preg_match("/^[a-zA-Z-' ]*$/",$this->name) || !preg_match("/^[a-zA-Z-' ]*$/",$this->surname)) {
        return true;
      }

    return false;

   }


   
   public function checkId()
   {
         if( strlen($this->id) < 13 )
         {
             return true;
 
 
         }
 
         return false ;
 
 
   }


   // check funtion to calculate number
 /* public function checkNumber()
  {
    if ( strlen($this->phone) < 10  ) 
    {

         return true ;
    }
    
     return false;


  }*/

}

   /***************************************************************************************************** */
 class manager extends database {
   
    public $managerid;
    public $name;
    public $departmentName;
    public $positions;
 

    public  function checkfield()
  {   
       $bool =  false;   

     if( empty ($this->name)|| empty($this->departmentName) || empty($positions))
     {

         $bool = true;

     }
    
      return $bool;


   }

    
   public function checkname(){



    if (!preg_match("/^[a-zA-Z-' ]*$/",$this->name)) {
        return true;
      }

    return false;

   }




 }
























?>