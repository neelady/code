<?php

 
class database{


 

    protected $hostname = "localhost";
    protected $db = "code";
    protected $Username = "root";
    protected $Password = "";
     
      protected function conn(){
  
          $conn = mysqli_connect($hostname,$Username,$Password,$db) Or DIE ("unable to connect database");
  
  
          return $conn;
  
      }
    
  
  }
  

class account extends database {


  public $email;
  public $password;
  public $retypePassword;
   

  public function checkEmpty()
  {

      if ( !empty($this->email)|| !empty($this->password)|| !empty($this->retypePasswword)){


           return false;


      }
   

      return true;



  }

  public function CheckEmail ()
  {


    
    if (!filter_var($this->email, FILTER_VALIDATE_EMAIL)) {
      return false;
      }else
      {
      
        return true;
      }

  }




  public function checkMatch()
  {

      if($this->password != $this->retypePassword)
      {


        return false;

      }

    return true;

  }


    public function checkAccount()

    {
        $sql = "SELECT email From account WHERE email = '".$this->email."';";
        $result = $this->conn()->query($sql);

         

         $num_rows = $result->num_rows;
          if($num_rows>0)
          {

            return false;
            

          }
         return true;




    }



}



class login extends database
{


    public $email;
    public $password;
    
   public  function checkfield()
  {
     if( empty ($this->email)|| empty($this->password))
     {

        return true;

     }
    
      return false;


   }
  


  //function processLogin(){

 /* $sql = "SELECT * FROM  register WHERE username = '".$this->username."' AND password = '".$this->password."'; ";
  $result = $this->connect()->query($sql);
  $row =  $result->fetch_assoc();

  if( $row['username'] == $this->username && $row['password'] == $this->password )
  {
    $_SESSION['userid'] = $row['Id'];
    $_SESSION['username'] = $row['username'];
      return true;
         

  }
  else {

   
    return false;

  }
   */
  
  
 }
















?>