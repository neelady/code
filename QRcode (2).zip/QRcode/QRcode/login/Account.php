
<?php

include("classes.php");

 

$hostname = "localhost";
$db = "code";
$Username = "root";
$Password = "";
$conn = mysqli_connect($hostname,$Username,$Password,$db) Or DIE ("unable to connect database");

 $user = new account();
if(isset($_POST['submit']))
{

    $user->email =$_POST['email'];
    $user->password =$_POST['password'];
    $user->retypePassword =$_POST['retype'];
   
        $sql = " INSERT INTO `account`( `email`, `password`) VALUES (?,?)";
        
     
     
		$stmt = mysqli_stmt_init($conn);
		if(!mysqli_stmt_prepare($stmt,$sql))
		{
				
		  echo ' <script  type = "text/javascript">  alert("SQL ERROR") </script>';
		  exit();
			 
		} 
		else{
  
		 
		   mysqli_stmt_bind_param( $stmt,"ss",$user->email, $user->password);
		   mysqli_stmt_execute($stmt);
		   
		   if(mysqli_query($conn,$sql))
		   {
			 
			  echo ' <script  type = "text/javascript">  alert(" record saved Successfully") </script>';
			  exit();
	
		   }
           
        }
    }

        




























?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Sign Up Form by Colorlib</title>

    <!-- Font Icon -->
    <link rel="stylesheet" href="fonts/material-icon/css/material-design-iconic-font.min.css">

    <!-- Main css -->
    <link rel="stylesheet" href="css/style.css">
</head>
<body>


    <div class="main">
        <!-- Sing in  Form -->
        <section class="sign-in">
            <div class="container">
                <div class="signin-content">
                    <div class="signin-image">
                        <figure><img src="images/signin-image.jpg" alt="sing up image"></figure>
                        <a href="login.php" class="signup-image-link"> I Already have an Account</a>
                    </div>
    
                    <div class="signin-form">
                        <h2 class="form-title"> Create an Account</h2>
                        <form method="POST" class="register-form" id="login-form" action ="Account.php">
                            <div class="form-group">
                                <label for="your_name"><i class="zmdi zmdi-account material-icons-name"></i></label>
                                <input type="text" name="email" id="your_name" placeholder="Email" required />
                            </div>
                            <div class="form-group">
                                <label for="your_pass"><i class="zmdi zmdi-lock"></i></label>
                                <input type="password" name="password" id="your_pass" placeholder="Password" required/>
                            </div>

                            <div class="form-group">
                                <label for="your_pass"><i class="zmdi zmdi-lock"></i></label>
                                <input type="password" name="retype" id="your_pass" placeholder="Retype Password" required/>
                            </div>

                            <div class="form-group">
                                <input type="checkbox" name="remember-me" id="remember-me" class="agree-term" />
                                <label for="remember-me" class="label-agree-term"><span><span></span></span>Remember me</label>
                            </div>
                            <div class="form-group form-button">
                                <input type="submit" name="submit" id="signin" class="form-submit" value="submit" />
                            </div>
                        </form>
                        
                    </div>
                </div>
            </div>
        </section>
    
    </div>
    
    <!-- JS -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="js/main.js"></script>
    
</body><!-- This templates was made by Colorlib (https://colorlib.com) -->
</html>