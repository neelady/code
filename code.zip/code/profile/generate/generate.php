<?php

 //header("Content-Type: image/png");

 $hostname = "localhost";
 $db = "code";
 $Username = "root";
 $Password = "";
 $conn = mysqli_connect($hostname,$Username,$Password,$db) Or DIE ("unable to connect database");

 require"vendor/autoload.php";
 use Endriod\QrCode\QrCode;


 $query = "SELECT * FROM profile;";
 $result = mysqli_query($conn,$query);

 
 //$qrcode = new QrCode("I am here");

 //echo $qrcode->writeString();
 //die();


 while($rows = mysqli_fetch_array($result))
 {

    $name = $rows['name']; 
    $surname = $rows['surname']; 
    $id = $rows['id_num']; 
    $gender = $rows['gender']; 
    $email = $rows['email']; 
    $phone = $rows['phone'];
    $address = $rows['address1'];
    $Qname = $rows['Qname'];
    $Iname = $rows['Iname'];
    $year = $rows['date'];
    $Pname = $rows['Pname'];
    $Pdesc = $rows['desc_name'];
    $brand =$rows['brand'];
    $hobbies = $rows['hobbies'];
    $skills = $rows['skills'];
    $image =$rows['images'];

     $qrcode = new QrCode($name,$surname,$id,$gender,$email,$phone,$address,$Qname,$Iname,$year,$Pname,$Pdesc);

       echo $qrcode->writeString();
       die();
    $tempDir = 'temp/'; 
    //$codeContents = 'mailto:'.$name.'?subject='.urlencode($department).'&body='.urlencode($position);
    $filename = $name;
    $qrCode->writeFile($tempDir.'/qrcode.png');

   // $codeContents = 'mailto:'.$name.'?subject='.urlencode($department).'&body='.urlencode($position); 
   // $qrcode = new QrCode($codeContents, $tempDir.''.$filename.'.png', QR_ECLEVEL_L, 5);
	//QRcode::png($codeContents, $tempDir.''.$filename.'.png', QR_ECLEVEL_L, 5);

 }




/*require_once 'phpqrcode/qrlib.php';
$path ="temp/";
$file =$path.uniqid()."png";

// the output
   $text = "";
QRcode::png($text,$file ,'L',10,2);


echo "<center> <img src'".$file."'><center>";*/




 

?>