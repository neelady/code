

<?php

class database{


 

    protected $hostname = "localhost";
    protected $db = "code";
    protected $Username = "root";
    protected $Password = "";
     
      protected function conn(){
  
          $conn = mysqli_connect($hostname,$Username,$Password,$db) Or DIE ("unable to connect database");
  
  
          return $conn;
  
      }
    
  
  }




class learner extends database {


    public $id;
    public $name;
    public $surname;
    public $gender;
    Public $phone;
    public $email;
    public $address1;
    public $hobbies;
    public $skills;
    public $brand;
    public $high;
    public $inst;
    public $year;
    public $pName;
    public $pDesc;
    public $cv;
    public $cvName;
    public $cvError;
    public $image;
    public $imageName;
    public $imageSize;
    public $imageError;
    public $imageType;
   
     public  function checkfield()
    {
      if( empty ($this->id)|| empty($this->name) || empty($this->surname)|| empty($this->gender)|| empty($this->phone)|| empty($this->address1)|| empty($this->hobbies)|| empty($this->skills)|| empty($this->brand)|| empty($this->high)|| empty($this->inst)|| empty($this->year)|| empty($this->pName)|| empty($this->pDesc))
      {
   
         return true;
   
      }
     
       return false;
   
   
    }
   
      public function checkNames()
      {
   
   
       if (!preg_match("/^[a-zA-Z-' ]*$/",$this->name) || !preg_match("/^[a-zA-Z-' ]*$/",$this->surname)) {
           return true;
         }
   
       return false;
   
      }
   
   
      
      public function checkId()
      {
            if( strlen($this->id) < 13 )
            {
                return true;
    
    
            }
    
            return false ;
    
    
      }

       public function checkimage()
       {
              

             //  $fileExt = explode('.',$this->imageName);
              // $fileActualExt = strtolower(end($fileExt));

              // $allowed = array('jpg','jpeg','png','pdf');

             

                 if($this->imageError === 0){
                 
                        move_uploaded_file($this->image,"pictures".$this->imageName);
                        return false; 
                    

                 }

                else{

                      return true;


               }



              }


              public function checkCV ()
              {
                     
                if($this->cvError === 0){

                    move_uploaded_file($this->cv,"resumes".$this->cvName);
                    return false;


                }else{

                  return true;




                }







              }
   
 

              //end of classs
      
    }

     



?>


