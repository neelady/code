<?php
 include("config.php");



  $profile = new PDO("mysql:host=localhost;dbname=code","root","");

  $learner = new learner();
  if(isset($_POST['submit']))
  {

    $learner->id = $_POST['id'];
    $learner->name = $_POST['first'];
    $learner->surname = $_POST['last'];
    $learner->gender = $_POST['gender'];
    $learner->phone = $_POST['phone'];
    if(isset($_POST['address'])){
     $learner->address1 = $_POST['address'];  
    }
    $learner->hobbies = $_POST['hobbies'];
    $learner->brand = $_POST['brand'];
    $learner->skills = $_POST['skills'];
    $learner->high = $_POST['Qname'];
    $learner->inst = $_POST['Iname'];
    $learner->year = $_POST['date'];
    $learner->pName = $_POST['Pname'];
    $learner->pDesc = $_POST['desc'];

     // store file in the object
     $imageName  = $_FILES['image']['name'];
     $imageSize  = $_FILES['image']['size'];
     $imageError = $_FILES['image']['error'];
     $imageType  = $_FILES['image']['type'];
     $learner->image =  addslashes(file_get_contents($_FILES['image']['tmp_name']));
     
     // store my resume in a folder 
     $learner->cv = file_get_contents($_FILES['cv']['tmp_name']);
     $learner->cvError = $_FILES['cv']['error'];
     $learner->cvName = $_FILES['cv']['name'];
     
     
    


     
     if($learner->checkfield() == true){


		echo ' <script  type = "text/javascript">  alert("All field  required") </script>';
        



	   }elseif($learner->checkNames() == true){
			  
		echo ' <script  type = "text/javascript">  alert("Name and Surname Must Contain Only Letters") </script>';
        

		
	   }
	   elseif($learner->checkid()){

		echo ' <script  type = "text/javascript">  alert("Invalid ID Number") </script>';
       

	   } 
	   /*elseif($learner->checkimage() == true){

        echo ' <script  type = "text/javascript">  alert("Error occured while uploading your image") </script>';



	   }*/ elseif($learner->checkCV()==true){

		echo ' <script  type = "text/javascript">  alert("Error occured while uploading your cv") </script>';



	   }else{


        $stmt = $profile->prepare("INSERT INTO `profile`( `name`, `surname`, `id_num`, `gender`, `phone`, `address1`, `Qname`, `Iname`, `date`, `Pname`, `desc_name`, `skills`, `brand`, `hobbies`, `cv`, `images`) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
        $stmt->bindParam(1,$learner->name);
        $stmt->bindParam(2,$learner->surname);
        $stmt->bindParam(3,$learner->id);
        $stmt->bindParam(4,$learner->gender);
        $stmt->bindParam(5,$learner->phone);
        $stmt->bindParam(6,$learner->address1);
        $stmt->bindParam(7,$learner->high);
        $stmt->bindParam(8,$learner->inst);
        $stmt->bindParam(9,$learner->year);
        $stmt->bindParam(10,$learner->pName);
        $stmt->bindParam(11,$learner->pDesc);
        $stmt->bindParam(12,$learner->skills);
        $stmt->bindParam(13,$learner->brand);
        $stmt->bindParam(14,$learner->hobbies);
        $stmt->bindParam(15,$learner->cv);
        $stmt->bindParam(16,$learner->image);

        $stmt->execute();

        


       }

      















    
     //last if statement

  }
     



















  


?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>form-v1 by Colorlib</title>
	<!-- Mobile Specific Metas -->
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<!-- Font-->
	
</head>
<body>
	
		        <form class="form-register" action="createprofile.php" method="POST"  enctype="multipart/form-data">
		        	  <h2>
			            	
			            </h2>
			            <section>
			                
									<h3 class="heading">Peronal Infomation</h3>
									<p>Please enter your infomation and proceed to the next step so we can build your accounts.  </p>
							
										<fieldset>
											<legend>First Name</legend>
											<input type="text" class="form-control" id="first-name" name="first" placeholder="First Name" required>
										</fieldset>
								
										<fieldset>
											<legend>Last Name</legend>
											<input type="text" class="form-control" id="last-name" name="last" placeholder="Last Name" required>
										</fieldset>
								
										<fieldset>
											<legend>ID Number</legend>
											<input type="text" class="form-control" id="last-name" name="id" placeholder="ID Number" maxlength="13" required>
										</fieldset>
								

								
										<fieldset>
											<legend>Gender</legend>
											<input type="radio"  class="form-control" id="male"   name="gender" value="male">
                                            <label for="male">Male</label><br>
                                            <input type="radio"  class="form-control" id="female" name="gender" value="female">
                                            <label for="female">Female</label><br>
                                            <input type="radio"  class="form-control" id="other"  name="gender" value="other">
                                             <label for="other">Other</label>
										</fieldset>
								
								
										<fieldset>
											<legend>Your Email</legend>
											<input type="text" name="email" id="your_email" class="form-control" pattern="[^@]+@[^@]+.[a-zA-Z]{2,6}" placeholder="example@email.com" required>
										</fieldset>
								
								
										<fieldset>
											<legend>Phone Number</legend>
											<input type="text" class="form-control" id="phone" name="phone" placeholder="+1 888-999-7777" required>
										</fieldset>
								
							
										<fieldset>
											<legend>Address</legend>
											
                                            <label for="inputAddress">Address</label><br>
											<textarea class="form-control" id="exampleFormControlTextarea1" name ="address" rows="5"></textarea><br>
                                          
                                          
                                            
										</fieldset>
									




							
			            </section>
						<!-- SECTION 2 -->
			            <h2>
			            	
			            	<span class="step-text">Education</span>
			            </h2>
			            <section>
			                
									<h3 class="heading">Education</h3>
									<p>Please enter your infomation and proceed to the next step so we can build your profile.</p>
							
										<fieldset>
											<legend>Qualification Name</legend>
											<input type="text" class="form-control" id="Qname" name="Qname" placeholder="Qualification Name" required>
										</fieldset>
									
										<fieldset>
											<legend> Institution Name</legend>
											<input type="text" class="form-control" id="Iname" name="Iname" placeholder="Institution Name" required>
										</fieldset>

										<fieldset>
											<legend> Year Obtained</legend>
											<input type="date" class="form-control" id="date" name="date" min="2005-01-02" max="2020-10-29" placeholder="Year Obtained" required>
										</fieldset>

										<fieldset>
											<legend>Final Year Project</legend>
											<label for="project"> Project Name</label><br>
											<input type="text" class="form-control" id="date" name="Pname"  placeholder="Project Name" required><br>
											<label for="project"> Project Description</label><br>
											<textarea class="form-control" id="exampleFormControlTextarea1" name ="desc" rows="5"></textarea><br>
										</fieldset>

										<fieldset>
											<legend>Technical Skills</legend>
											<textarea class="form-control" id="exampleFormControlTextarea1" name ="skills" rows="5"></textarea><br>
										</fieldset>
									
				              
			            </section>
			            <!-- SECTION 3 -->
			            <h2>
			            	
			            	<span class="step-text">Interests</span>
			            </h2>
			            <section>
					  


						<fieldset>
						<legend> Personal Brand</legend>
						<input type="text" class="form-control" id="brand" name="brand" placeholder="Personal Brand" required>
						</fieldset>
						<fieldset>
						<legend> Hobbies</legend>
						<textarea class="form-control" id="exampleFormControlTextarea1" name ="hobbies" rows="3"></textarea>
						</fieldset>
                  
               




			              
						</section>
						


						</section>
			            <!-- SECTION 3 -->
			            <h2>
			            	
			            	<span class="step-text">Attachments</span>
			            </h2>
			            <section>
					  


						<fieldset>
						<legend> Upload CV</legend>
						<input type="file" class="form-control"  name="cv"  required>
						</fieldset>
						<fieldset>
						<legend> Image</legend>
						<input type="file" class="form-control"  name="image"  required>
						</fieldset>
                  
						</section>
						

                       <button name="submit">submit</button>
		        	
		        </form>
		
	
    </body>
    </html>