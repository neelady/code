<?php



class database{


 

    protected $hostname = "localhost";
    protected $db = "code";
    protected $Username = "root";
    protected $Password = "";
     
      protected function conn(){
  
          $conn = mysqli_connect($hostname,$Username,$Password,$db) Or DIE ("unable to connect database");
  
  
          return $conn;
  
      }
    
  
  }

class manager extends database {
   
    public $managerid;
    public $name;
    public $departmentName;
    public $positions;
 

    public  function checkfield()
  {   
       $bool =  false;   

     if( empty ($this->name)|| empty($this->departmentName) || empty($positions))
     {

         $bool = true;

     }
    
      return $bool;


   }

    
   public function checkname(){



    if (!preg_match("/^[a-zA-Z-' ]*$/",$this->name)) {
        return true;
      }

    return false;

   }




 }







?>